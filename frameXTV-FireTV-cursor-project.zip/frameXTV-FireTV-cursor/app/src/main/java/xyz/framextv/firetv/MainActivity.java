package xyz.framextv.firetv;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://framextv.xyz";

    private FrameLayout root;
    private WebView webView;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    private boolean cursorEnabled = true;
    private float cursorX;
    private float cursorY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        root.addView(webView);

        root.post(() -> {
            cursorX = root.getWidth() / 2f;
            cursorY = root.getHeight() / 2f;
            injectWebCursor();
            updateWebCursor();
        });

        configureWebView();

        if (savedInstanceState == null) {
            webView.loadUrl(HOME_URL);
        } else {
            webView.restoreState(savedInstanceState);
        }

        webView.requestFocus();
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setUserAgentString(settings.getUserAgentString() + " frameXTV-FireTV/1.2");

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectWebCursor();
                updateWebCursor();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }

                customView = view;
                customViewCallback = callback;
                setWebCursorVisible(false);
                webView.setVisibility(View.GONE);
                root.addView(customView, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                ));
                customView.requestFocus();
            }

            @Override
            public void onHideCustomView() {
                hideCustomView();
            }
        });
    }

    private void injectWebCursor() {
        if (webView == null) return;
        String js = "(function(){" +
                "var id='framextv-fire-cursor';" +
                "var c=document.getElementById(id);" +
                "if(!c){" +
                "c=document.createElement('div');" +
                "c.id=id;" +
                "c.style.position='fixed';" +
                "c.style.width='26px';" +
                "c.style.height='26px';" +
                "c.style.border='3px solid white';" +
                "c.style.borderRadius='50%';" +
                "c.style.background='rgba(255,255,255,0.15)';" +
                "c.style.boxShadow='0 0 0 2px black,0 0 7px black';" +
                "c.style.pointerEvents='none';" +
                "c.style.zIndex='2147483647';" +
                "c.style.transform='translate(-50%,-50%)';" +
                "c.style.margin='0';" +
                "c.style.padding='0';" +
                "var d=document.createElement('div');" +
                "d.style.position='absolute';" +
                "d.style.left='50%';" +
                "d.style.top='50%';" +
                "d.style.width='5px';" +
                "d.style.height='5px';" +
                "d.style.background='white';" +
                "d.style.border='1px solid black';" +
                "d.style.borderRadius='50%';" +
                "d.style.transform='translate(-50%,-50%)';" +
                "c.appendChild(d);" +
                "(document.documentElement||document.body).appendChild(c);" +
                "}" +
                "})();";
        webView.evaluateJavascript(js, null);
    }

    private void updateWebCursor() {
        if (webView == null || root == null || root.getWidth() <= 0 || root.getHeight() <= 0) return;
        float xPercent = (cursorX / root.getWidth()) * 100f;
        float yPercent = (cursorY / root.getHeight()) * 100f;
        String display = cursorEnabled && customView == null ? "block" : "none";
        String js = "(function(){var c=document.getElementById('framextv-fire-cursor');" +
                "if(c){c.style.left='" + xPercent + "vw';c.style.top='" + yPercent +
                "vh';c.style.display='" + display + "';}})();";
        webView.evaluateJavascript(js, null);
    }

    private void setWebCursorVisible(boolean visible) {
        if (webView == null) return;
        String js = "(function(){var c=document.getElementById('framextv-fire-cursor');" +
                "if(c)c.style.display='" + (visible ? "block" : "none") + "';})();";
        webView.evaluateJavascript(js, null);
    }

    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme();
        if (scheme == null || scheme.equals("http") || scheme.equals("https")) {
            return false;
        }

        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        } catch (ActivityNotFoundException ignored) {
        }
        return true;
    }

    private void hideCustomView() {
        if (customView == null) return;

        root.removeView(customView);
        customView = null;
        webView.setVisibility(View.VISIBLE);
        webView.requestFocus();
        injectWebCursor();
        updateWebCursor();

        if (customViewCallback != null) {
            customViewCallback.onCustomViewHidden();
            customViewCallback = null;
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int keyCode = event.getKeyCode();

        if (customView != null) {
            return super.dispatchKeyEvent(event);
        }

        if (keyCode == KeyEvent.KEYCODE_MENU) {
            if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
                cursorEnabled = !cursorEnabled;
                if (cursorEnabled) {
                    injectWebCursor();
                }
                updateWebCursor();
            }
            return true;
        }

        if (cursorEnabled && isCursorKey(keyCode)) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
                    if (event.getRepeatCount() == 0) clickAtCursor();
                } else {
                    moveCursor(keyCode, event.getRepeatCount());
                }
            }
            return true;
        }

        return super.dispatchKeyEvent(event);
    }

    private boolean isCursorKey(int keyCode) {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP
                || keyCode == KeyEvent.KEYCODE_DPAD_DOWN
                || keyCode == KeyEvent.KEYCODE_DPAD_LEFT
                || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
                || keyCode == KeyEvent.KEYCODE_DPAD_CENTER
                || keyCode == KeyEvent.KEYCODE_ENTER;
    }

    private void moveCursor(int keyCode, int repeatCount) {
        if (root.getWidth() <= 0 || root.getHeight() <= 0) return;

        float density = getResources().getDisplayMetrics().density;
        float step = (18f + Math.min(repeatCount, 12) * 2.5f) * density;
        float margin = 8f * density;

        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                cursorX -= step;
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                cursorX += step;
                break;
            case KeyEvent.KEYCODE_DPAD_UP:
                cursorY -= step;
                if (cursorY < margin) {
                    webView.scrollBy(0, -(int) (110f * density));
                    cursorY = margin;
                }
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                cursorY += step;
                if (cursorY > root.getHeight() - margin) {
                    webView.scrollBy(0, (int) (110f * density));
                    cursorY = root.getHeight() - margin;
                }
                break;
            default:
                return;
        }

        cursorX = Math.max(margin, Math.min(cursorX, root.getWidth() - margin));
        cursorY = Math.max(margin, Math.min(cursorY, root.getHeight() - margin));
        updateWebCursor();
    }

    private void clickAtCursor() {
        long now = SystemClock.uptimeMillis();
        MotionEvent down = MotionEvent.obtain(
                now, now, MotionEvent.ACTION_DOWN, cursorX, cursorY, 0
        );
        MotionEvent up = MotionEvent.obtain(
                now, now + 70, MotionEvent.ACTION_UP, cursorX, cursorY, 0
        );
        webView.dispatchTouchEvent(down);
        webView.dispatchTouchEvent(up);
        down.recycle();
        up.recycle();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (customView != null) {
                hideCustomView();
                return true;
            }
            if (webView.canGoBack()) {
                webView.goBack();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        immersiveMode();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            immersiveMode();
            updateWebCursor();
        }
    }

    private void immersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
        }
        super.onDestroy();
    }
}
