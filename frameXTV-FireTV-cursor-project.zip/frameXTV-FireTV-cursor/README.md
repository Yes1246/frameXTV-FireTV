# frameXTV Fire TV wrapper (cursor edition)

Fire TV WebView wrapper for https://framextv.xyz.

Remote controls:
- D-pad arrows: move the on-screen mouse cursor.
- Center/OK: click at the cursor.
- Hold a D-pad direction: faster cursor movement.
- At the top/bottom edge, Up/Down scrolls the webpage.
- Menu button (three horizontal lines): toggle cursor mode on/off.
- Back: webpage back; when video is full-screen, exits full-screen first.

The cursor is enabled by default and disappears automatically while HTML5 video is in full-screen mode.
