# frameXTV Fire TV Wrapper

A small Fire TV / Android TV app that opens **https://framextv.xyz** full-screen in a WebView.

## What it does

- Opens framextv.xyz immediately
- Uses landscape/full-screen TV mode
- Enables JavaScript, cookies, DOM storage, and HTML5 media playback
- Keeps the Fire TV screen awake while the app is open
- Supports HTML5 fullscreen video
- Uses the Fire TV Back button for web history, then exits the app
- Appears as a TV app through the Leanback launcher category

## Build with Android Studio

1. Install Android Studio.
2. Open this folder as a project.
3. Let Gradle sync and install Android SDK 35 if prompted.
4. Choose **Build > Build APK(s)**.
5. The debug APK will be at:
   `app/build/outputs/apk/debug/app-debug.apk`

## Build with GitHub Actions

This project includes `.github/workflows/build-apk.yml`.
Push the folder to a GitHub repository, open the **Actions** tab, run **Build Fire TV APK**, then download the `frameXTV-FireTV-debug-apk` artifact.

## Install on Fire TV with ADB

Enable Developer Options / ADB debugging on the Fire TV, connect from a computer, then run:

```bash
adb connect FIRE_TV_IP:5555
adb install -r app-debug.apk
```

The app should then appear as **frameXTV** in the Apps area.

## Notes

This is only a browser wrapper. It does not modify, download, decrypt, or bypass restrictions on any content supplied by the website. Playback still depends on whether the site's player, codec, DRM, and remote-control behavior work in the Fire TV WebView on your specific device.
